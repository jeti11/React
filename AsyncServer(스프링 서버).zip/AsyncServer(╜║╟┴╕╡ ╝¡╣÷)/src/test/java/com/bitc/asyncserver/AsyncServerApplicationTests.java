package com.bitc.asyncserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsyncServerApplicationTests {

  @Test
  void contextLoads() {
  }

}
