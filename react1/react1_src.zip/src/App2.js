import React from "react";
import Library from "./day1/Library";

function App2() {
  return (
    <div>
      <Library />
    </div>
  )
}

export default App2;