import React from "react";

function BootstrapCDN(props) {
  return (
    <div className={'container'}>
      <button className={'btn btn-primary'}>부트스트랩 적용 버튼</button>
    </div>
  )
}


export default BootstrapCDN;